<?php
// @codingStandardsIgnoreFile
// This file is intentionally empty so that it overwrites when sites are
// updated from a zip/tarball without deleting the /core folder first.
// @todo: remove in 8.3.x
